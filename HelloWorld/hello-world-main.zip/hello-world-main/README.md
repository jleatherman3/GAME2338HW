# hello-world

Hello, this is Jo Marie. 

I am currently going to college for a degree in Video Game Development.
I am learning Git as part of my Videogame Testing class.

I look forward to learning new things and expanding my horizons.
